#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <cmath>
#include <cstdio>

const float PI = 3.14159265f;

const float COLOR_SKY[] = {0.0f, 0.6f, 1.0f};
const float COLOR_SUN[] = {1.0f, 1.0f, 0.0f};
const float COLOR_CLOUD[] = {1.0f, 1.0f, 1.0f};
const float COLOR_GRASS[] = {0.2f, 0.8f, 0.2f};
const float COLOR_ROAD[] = {0.3f, 0.3f, 0.3f};
const float COLOR_ROAD_LINE[] = {1.0f, 1.0f, 1.0f};

const float COLOR_MOSQUE_WALL[] = {0.65f, 0.2f, 0.15f};
const float COLOR_MOSQUE_DOME[] = {1.0f, 0.85f, 0.0f};
const float COLOR_MOSQUE_TRIM[] = {0.95f, 0.9f, 0.7f};
const float COLOR_MOSQUE_DOOR[] = {0.1f, 0.05f, 0.0f};

const float COLOR_TREE_TRUNK[] = {0.4f, 0.25f, 0.1f};
const float COLOR_TREE_LEAVES[] = {0.1f, 0.5f, 0.1f};
const float COLOR_FLOWER_PETAL[] = {1.0f, 0.4f, 0.0f};
const float COLOR_FLOWER_CENTER[] = {1.0f, 0.0f, 0.0f};

const float COLOR_BUILDING1[] = {0.4f, 0.3f, 0.7f};
const float COLOR_BUILDING2[] = {0.9f, 0.7f, 0.8f};
const float COLOR_BUILDING3[] = {0.95f, 0.65f, 0.5f};
const float COLOR_MOUNTAIN[] = {0.5f, 0.6f, 0.8f};

const float COLOR_CAR_RED[] = {0.9f, 0.1f, 0.1f};
const float COLOR_CAR_TEAL[] = {0.4f, 0.9f, 0.85f};
const float COLOR_CAR_CAB[] = {0.8f, 0.2f, 0.2f};
const float COLOR_CAR_YELLOW[] = {1.0f, 0.9f, 0.0f};
const float COLOR_BUS_WINDOW[] = {0.3f, 0.7f, 1.0f};
const float COLOR_TIRE[] = {0.0f, 0.0f, 0.0f};
const float COLOR_HUBCAP[] = {1.0f, 1.0f, 1.0f};

const float CAR1_SPEED = 0.08f;
const float CAR2_SPEED = 0.06f;
const float CAR3_SPEED = 0.10f;

float car1_x = -25.0f;
float car2_x = -10.0f;
float car3_x = 15.0f;

inline void setColor(const float color[]) {
    glColor3fv(color);
}

inline void setColorRGB(float r, float g, float b) {
    glColor3f(r, g, b);
}

void drawRectangle(float x, float y, float width, float height) {
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();
}

void drawCircle(float centerX, float centerY, float radius) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY);
    for (int i = 0; i <= 36; i++) {
        float angle = i * 2.0f * PI / 36.0f;
        glVertex2f(centerX + cos(angle) * radius,
                   centerY + sin(angle) * radius);
    }
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3) {
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawWheel(float x, float y, float radius) {
    setColor(COLOR_TIRE);
    drawCircle(x, y, radius);
    setColor(COLOR_HUBCAP);
    drawCircle(x, y, radius * 0.4f);
}

void drawSky() {
    setColor(COLOR_SKY);
    drawRectangle(-40, 0, 80, 40);
}

void drawSun() {
    setColor(COLOR_SUN);
    drawCircle(28, 32, 3.5f);
}

void drawCloud(float x, float y, float scale) {
    setColor(COLOR_CLOUD);
    drawCircle(x, y, 1.5f * scale);
    drawCircle(x + 2.0f * scale, y - 0.5f * scale, 1.8f * scale);
    drawCircle(x + 4.0f * scale, y, 1.5f * scale);
    drawCircle(x + 1.0f * scale, y + 1.0f * scale, 1.3f * scale);
    drawCircle(x + 3.0f * scale, y + 1.0f * scale, 1.3f * scale);
}

void drawClouds() {
    drawCloud(-25, 30, 1.2f);
    drawCloud(-5, 28, 1.5f);
    drawCloud(15, 32, 1.0f);
}

void drawMountain(float x, float y, float width, float height) {
    setColor(COLOR_MOUNTAIN);
    drawTriangle(x, y, x + width/2, y + height, x + width, y);
}

void drawMountains() {
    drawMountain(-35, 12, 25, 10);
    drawMountain(-15, 10, 30, 12);
    drawMountain(10, 11, 25, 9);
    drawMountain(25, 13, 20, 8);
}

void drawBuilding(float x, float y, float width, float height, const float color[]) {
    setColor(color);
    drawRectangle(x, y, width, height);
}

void drawCityBuildings() {
    drawBuilding(-20, 12, 8, 12, COLOR_BUILDING1);
    setColor(COLOR_CLOUD);
    drawRectangle(-18, 15, 2, 2);
    drawRectangle(-18, 19, 2, 2);
    drawRectangle(-14, 15, 2, 2);
    drawRectangle(-14, 19, 2, 2);

    drawBuilding(5, 10, 6, 14, COLOR_BUILDING2);
    setColorRGB(0.6f, 0.6f, 0.8f);
    drawBuilding(11, 10, 5, 11, COLOR_BUILDING2);

    drawBuilding(18, 8, 10, 16, COLOR_BUILDING3);
    setColorRGB(0.8f, 0.5f, 0.3f);
    drawRectangle(18, 11, 10, 1);
    drawRectangle(18, 15, 10, 1);
    drawRectangle(18, 19, 10, 1);
}

void drawDome(float x, float y, float radius) {
    setColor(COLOR_MOSQUE_DOME);
    drawRectangle(x - radius, y, radius*2, radius*0.3f);
    drawCircle(x, y + radius*0.3f, radius);
}

void drawMinaret(float x, float y, float height) {
    setColor(COLOR_MOSQUE_WALL);
    drawRectangle(x - 0.8f, y, 1.6f, height);
    drawDome(x, y + height, 1.0f);
    setColor(COLOR_MOSQUE_DOME);
    drawCircle(x, y + height + 1.5f, 0.5f);
}

void drawPointedArch(float x, float y, float width, float height, bool filled) {
    if (filled) {
        glBegin(GL_POLYGON);
        glVertex2f(x, y);
        glVertex2f(x, y + height * 0.6f);
        for (int i = 0; i <= 10; i++) {
            float t = i / 10.0f;
            float px = x + width * 0.5f * (1 - cos(t * PI/2));
            float py = y + height * 0.6f + height * 0.4f * sin(t * PI/2);
            glVertex2f(px, py);
        }
        for (int i = 10; i >= 0; i--) {
            float t = i / 10.0f;
            float px = x + width - width * 0.5f * (1 - cos(t * PI/2));
            float py = y + height * 0.6f + height * 0.4f * sin(t * PI/2);
            glVertex2f(px, py);
        }
        glVertex2f(x + width, y + height * 0.6f);
        glVertex2f(x + width, y);
        glEnd();
    } else {
        setColor(COLOR_MOSQUE_DOOR);
        drawRectangle(x, y, width, height * 0.65f);
        drawTriangle(x, y + height * 0.65f,
                    x + width/2, y + height,
                    x + width, y + height * 0.65f);
    }
}

void drawMosque() {
    float baseY = 8.0f;

    setColorRGB(0.3f, 0.15f, 0.1f);
    drawRectangle(-14, baseY, 28, 1.0f);

    setColor(COLOR_MOSQUE_WALL);
    drawRectangle(-4, baseY + 1, 8, 10);
    drawRectangle(-12, baseY + 1, 8, 8);
    drawRectangle(4, baseY + 1, 8, 8);

    setColor(COLOR_MOSQUE_TRIM);
    drawRectangle(-12, baseY + 8.5f, 24, 0.5f);
    drawRectangle(-4, baseY + 10.5f, 8, 0.5f);

    setColor(COLOR_MOSQUE_TRIM);
    drawRectangle(-2.5f, baseY + 1, 5, 7);
    setColor(COLOR_MOSQUE_DOOR);
    drawRectangle(-1.8f, baseY + 1, 3.6f, 6);

    for (int i = 0; i < 3; i++) {
        drawPointedArch(-11 + i * 2.5f, baseY + 3, 1.8f, 3.5f, false);
        drawPointedArch(4.5f + i * 2.5f, baseY + 3, 1.8f, 3.5f, false);
    }

    drawDome(0, baseY + 11, 3.0f);
    drawDome(-7, baseY + 9, 2.2f);
    drawDome(7, baseY + 9, 2.2f);
    drawDome(-4, baseY + 9, 1.8f);
    drawDome(4, baseY + 9, 1.8f);

    drawMinaret(-13, baseY + 1, 12);
    drawMinaret(13, baseY + 1, 12);

    setColor(COLOR_MOSQUE_DOME);
    drawCircle(0, baseY + 14.5f, 0.6f);
    drawCircle(-7, baseY + 11.8f, 0.5f);
    drawCircle(7, baseY + 11.8f, 0.5f);
}

void drawTree(float x, float y, float scale) {
    setColor(COLOR_TREE_TRUNK);
    drawRectangle(x - 0.8f * scale, y, 1.6f * scale, 4 * scale);
    setColor(COLOR_TREE_LEAVES);
    drawCircle(x, y + 5 * scale, 2.5f * scale);
    drawCircle(x - 2 * scale, y + 4 * scale, 2.0f * scale);
    drawCircle(x + 2 * scale, y + 4 * scale, 2.0f * scale);
    drawCircle(x - 1.5f * scale, y + 7 * scale, 1.8f * scale);
    drawCircle(x + 1.5f * scale, y + 7 * scale, 1.8f * scale);
}

void drawFlower(float x, float y) {
    setColor(COLOR_FLOWER_PETAL);
    for (int i = 0; i < 6; i++) {
        float angle = i * PI / 3.0f;
        drawCircle(x + cos(angle) * 0.5f, y + sin(angle) * 0.5f, 0.3f);
    }
    setColor(COLOR_FLOWER_CENTER);
    drawCircle(x, y, 0.25f);
}

void drawGrassAndTrees() {
    setColor(COLOR_GRASS);
    drawRectangle(-40, 0, 80, 8);

    drawTree(-28, 2, 1.0f); drawTree(-32, 1, 0.8f); drawTree(-18, 2, 0.9f);
    drawTree(22, 2, 1.0f); drawTree(28, 1, 0.85f); drawTree(32, 2, 0.9f);
    drawTree(-22, -1, 0.6f); drawTree(-15, -1, 0.5f); drawTree(-8, -1, 0.6f);
    drawTree(10, -1, 0.55f); drawTree(17, -1, 0.6f); drawTree(25, -1, 0.5f);
    drawTree(35, -1, 0.55f);

    drawFlower(-26, 3); drawFlower(-30, 2); drawFlower(-20, 4);
    drawFlower(-14, 3); drawFlower(20, 3); drawFlower(24, 2);
    drawFlower(30, 4); drawFlower(34, 3);
}

void drawRoad() {
    setColor(COLOR_ROAD);
    drawRectangle(-40, -4, 80, 4);
    setColor(COLOR_ROAD_LINE);
    for (float x = -38; x < 38; x += 4) {
        drawRectangle(x, -2.2f, 2.5f, 0.3f);
    }
}

void drawRedCar(float x, float y) {
    setColorRGB(0.9f, 0.1f, 0.1f);
    drawRectangle(x, y, 4.0f, 1.5f);
    drawRectangle(x + 0.8f, y + 1.5f, 2.5f, 1.0f);
    setColorRGB(0.7f, 0.9f, 1.0f);
    drawRectangle(x + 1.2f, y + 1.7f, 0.8f, 0.6f);
    drawRectangle(x + 2.3f, y + 1.7f, 0.8f, 0.6f);
    drawWheel(x + 0.8f, y, 0.4f);
    drawWheel(x + 3.2f, y, 0.4f);
}

void drawTealTruck(float x, float y) {
    setColor(COLOR_CAR_TEAL);
    drawRectangle(x, y + 0.5f, 5.0f, 3.0f);
    setColor(COLOR_CAR_CAB);
    drawRectangle(x + 5.0f, y, 2.5f, 2.0f);
    setColorRGB(0.4f, 0.9f, 0.85f);
    drawRectangle(x + 5.5f, y + 1.2f, 1.5f, 0.7f);
    drawWheel(x + 1.2f, y, 0.5f);
    drawWheel(x + 3.8f, y, 0.5f);
    drawWheel(x + 6.5f, y, 0.5f);
}

void drawYellowBus(float x, float y) {
    setColor(COLOR_CAR_YELLOW);
    drawRectangle(x, y + 0.3f, 6.5f, 2.8f);
    setColor(COLOR_BUS_WINDOW);
    for (int i = 0; i < 5; i++) {
        drawRectangle(x + 0.8f + i * 1.1f, y + 1.5f, 0.8f, 1.0f);
    }
    drawWheel(x + 1.2f, y, 0.55f);
    drawWheel(x + 5.3f, y, 0.55f);
}

void drawVehicles() {
    drawRedCar(car1_x, -3.5f);
    drawTealTruck(car2_x, -3.5f);
    drawYellowBus(car3_x, -3.5f);
}

void drawScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawSky();
    drawSun();
    drawClouds();
    drawMountains();
    drawCityBuildings();
    drawMosque();
    drawGrassAndTrees();
    drawRoad();
    drawVehicles();
    glFlush();
}

void updateAnimation(int value) {
    car1_x += CAR1_SPEED;
    car2_x += CAR2_SPEED;
    car3_x += CAR3_SPEED;

    if (car1_x > 40) car1_x = -15;
    if (car2_x > 40) car2_x = -15;
    if (car3_x > 40) car3_x = -15;

    glutPostRedisplay();
    glutTimerFunc(30, updateAnimation, 0);
}

void initGL() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-40, 40, -5, 40);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1000, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Mosque Scene - Code::Blocks");

    initGL();
    glutDisplayFunc(drawScene);
    glutTimerFunc(0, updateAnimation, 0);

    printf("Mosque Scene Running!\n");

    glutMainLoop();
    return 0;
}
